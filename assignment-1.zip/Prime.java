/**
 * This program determines whether or not a number is prime.
 * 
 * @author: <your name here>
 * @date: <the date here>
 */
// Importing the Scanner
import java.util.Scanner;
public class Prime{
    
    public static void main(String[] args){

//   Here we are looking for the user input         
        Scanner input = new Scanner(System.in);
        System.out.println("Which number would you like to check to see is prime?");
        double number = input.nextInt();
// Here we are making sure that the number is under 10,000        
        while (number > 10000){
            System.out.println("Please put in a smaller number");
            number = input.nextInt();
        }
        while (number == 1 || number == 0 ){
            System.out.println("That number is not a valid number.");
            System.out.println("Please put in a valid number");
            number = input.nextInt();
        }
// Here we are converting the number to its root        
        double max;
        max = Math.sqrt(number);
        max = Math.floor(max);
// Here we are iterating over a for loop to figure out whether the number is prime or not            
        for(int i=2; i< max; i++){
            if(number%i == 0){
                System.out.println("The number is not prime. The smallest factor is " + i);
                break;
            }else{
                System.out.println("The number is prime.");
                break;
            }
        }
            
        
    }
}
 