## COMS S1004
## Assignment 1
## Due May 30 at 11:59PM
____________________________

### Problem Set (8 x 5pts = 40 points) 

Do the following exercises in Schneider and Gersting (7th edition):

Chapter 1: 10,11

Chapter 2: 19, 20, 23

Chapter 3: 17, 31,36

*Recommended: (not for credit)*: 
Chapter 1: 4, 12, 13, Challenge Work 1
Chapter 2: 7, 10, 11, 17, 18
Chapter 3: 1, 3, 11, 13,16, 19

### Programming (60 points)

1. Create an application in Java that asks a user for a number of hours, days, and years and computes the equivalent number of seconds (ignoring leap years). Edit the file file ``Seconds.java`` included here.

2. Implement your algorithm from problem 20 in Chapter 2 of Schneider and Gersting. That is, write a Java program that executes your algorithm and works for numbers smaller than 10,000. Edit the file ``Prime.java`` included here.

3. Create a personal web page using your CUNIX account. Your page should contain at least 1 image and 5 links. These pages should be rated "G". You do not need to submit your HTML code for this part of the assignment.

 

### Submitting your work:

1. **Problem set**: Submit a single pdf file for the problems set. Do this on Courseworks.
2. **Programming**: Submit the .java files on Codio. To do this simply press the complete button when you're done.
3. **Webpage**: Place your webpage on your CUNIX account in your ``public_html`` directory. Make sure the file is named index.html and that it is world readable. That is, make sure your page is viewable online.
