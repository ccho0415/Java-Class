/**
 * This program converts a number of hours, days, and years into seconds.
 * 
 * @author: <your name here>
 * @date: <the date here>
 */

import java.util.Scanner;

public class Seconds{
    
    public static void main(String[] args){
//  Here we are going to establish the datatype of some variables
    int hours;
    int days;
    int years;
    int seconds;
    int hoursToS;
    int daysToS;
    int yearsToS;  
    int totalseconds;       
//  Here we get the info from the user    
    Scanner userInput = new Scanner(System.in);
//  Next we ask them for the number of hours        
    System.out.println("Please enter a number of hours : ");
        hours = userInput.nextInt();
//  Next we ask them for the number of days        
    System.out.println("Please enter a number of days : ");
        days = userInput.nextInt();       
//  Next we ask them for the number of years        
    System.out.println("Please enter a number of years : ");        
        years = userInput.nextInt();   
//  Here are some calculations
    hoursToS = 3600*hours;
    daysToS = 86400 * days;
    yearsToS = 31536000 * years;
    totalseconds = hoursToS + daysToS + yearsToS;
    System.out.println(""+hours+" hours , "+days+" days and "+years+" years are "+totalseconds+" seconds");    
    }
}
 