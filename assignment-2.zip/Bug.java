//*********************************
// Christine Chong
// cc4190
// 06/06/2017
//
// Bug Class
//
// This class contains the methods 
// that moves and turns the Bug.
//*********************************
public class Bug{
    
    private int position;
    private int direction =1;
    
    public Bug(int initialPosition){
        position = initialPosition;            
    }
    
    public void turn(){
        if(direction == 0){
            direction = 1;
        }else{
            direction = 0;
        }    
    }
    
    public void move(){
        if(direction ==0){
            position--;
            getPosition();
        }else{
            position++;
            getPosition();
        }
    }
    
    public int getPosition(){
        System.out.println("Position : "+ position);
        return position;
    }
    
}