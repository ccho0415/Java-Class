//*********************************
// Christine Chong
// cc4190
// 06/06/2017
//
// BugTester Class
//
// It contains the main method.
//*********************************
public class BugTester{
    
    public static void main(String[] args){
        Bug bugsy = new Bug (10);
        bugsy.move();
        bugsy.turn();
        bugsy.move();
        bugsy.move();
        bugsy.move();
        bugsy.turn();
        bugsy.move();
        bugsy.move();
    }
    
}