//*********************************
// Christine Chong
// cc4190
// 06/06/2017
//
// Circuit Class
//
// This class contains the methods 
// that changes the state of switch
// one, switch two and the lamp.
//*********************************
public class Circuit {
    
    private int switchState1;
    private int switchState2;
    private int lampState; 
    
    public Circuit(){
        switchState1 =0;
        switchState2 =0;
        lampState =0;        
    }
    
    public int getFirstSwitchState(){
        if(switchState1 == 0){
            System.out.println("First Switch is DOWN");
            return switchState1;
        }else{
            System.out.println("First Switch is UP");
            return switchState1;
        }
  
    }
    
    public void toggleFirstSwitch(){
        if(switchState1 ==0){
            switchState1 =1;
        }else{
            switchState1 =0;
        }
        if(lampState ==0){
            lampState = 1;
        }else{
            lampState = 0;
        }
   } 
    
    public int getSecondSwitchState(){
        if (switchState2 == 0){
            System.out.println("Second Switch is DOWN");
            return switchState2;            
        }else{
            System.out.println("Second Switch is UP");
            return switchState2;            
        }        
    }
    
   public void toggleSecondSwitch(){
        if(switchState2 ==0){
            switchState2 =1;
        }else{
            switchState2 =0;
        }
        if(lampState ==0){
            lampState = 1;
        }else{
            lampState = 0;
        }
    }   
    
    public int getLampState(){
        if(lampState == 0){
            System.out.println("Lamp is OFF");
            return lampState;            
        }else{
            System.out.println("Lamp is ON");
            return lampState;            
        }        
    }
    
}
