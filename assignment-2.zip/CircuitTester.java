//*********************************
// Christine Chong
// cc4190
// 06/06/2017
//
// Circuit Tester Class
//
// This class contains the main method.
//*********************************
public class CircuitTester{
    
    public static void main (String[] args){
        Circuit test = new Circuit();
        
        test.getFirstSwitchState();
        test.getSecondSwitchState();
        test.getLampState();
        System.out.println("-----------------------");
        
        test.toggleFirstSwitch();
        test.getFirstSwitchState();
        test.getSecondSwitchState();
        test.getLampState();
        System.out.println("-----------------------");
        
        test.toggleSecondSwitch();
        test.getFirstSwitchState();
        test.getSecondSwitchState();
        test.getLampState();
        System.out.println("-----------------------");
        
        test.toggleFirstSwitch();
        test.getFirstSwitchState();
        test.getSecondSwitchState();
        test.getLampState();
        System.out.println("-----------------------");   
        
    }
}