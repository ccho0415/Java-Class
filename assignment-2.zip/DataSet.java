//*********************************
// Christine Chong
// cc4190
// 06/06/2017
//
// DataSet Class
//
// This class contains the methods 
// that checks if the inputted list has
// numeric, and sorts the list. With
// the numeric values in the list,
// there are methods that find the average
// of the numbers, the largest number,
// the smallest number and the range of
// the numbers. 
//*********************************
public class DataSet {
    private String list;
    private String[] listArray;   
    private Boolean valid;

    public DataSet(String inList){
        list = inList;
    }

    public void add(String list){
        valid = true;
        int max = list.length();
        listArray = list.split(",");        
        for(int i=0; i<max; i++){
            if(Character.isLetter(list.charAt(i))){
                valid = false;
            }
        }
    listHandler(valid, listArray);
    }

    public void listHandler(Boolean valid, String[] listArray){
        double[] numList = new double[listArray.length];
        if(valid == false){
            System.out.println("Not a valid input please try again");            
        }else{
            for(int i=0; i<listArray.length; i++){
                numList[i] = Double.parseDouble(listArray[i]);
            }
            sort(numList);
        }
    }
    
    public void sort(double[] numList){
        double temp;
        for(int j=1; j<=numList.length-1; j++){
            temp =numList[j];
            int i = j-1;
            while(i>-1 && (numList[i]>temp)){
               numList[i+1] = numList[i];
                i--;
            }
            numList[i+1] = temp;
        }
        size(numList);
        average(numList);
    }
    public void size(double[] array){
        int max = array.length -1;
        double smallest = array[0];
        double largest = array[max];
        double range = largest - smallest;
        System.out.println("Largest :"+largest); 
        System.out.println("Smallest :"+smallest); 
        System.out.println("Range :"+range); 
    }
    public void average(double[] array){
        double sum = 0;
        int count = 0;
        double average;
        for(int i=0; i<array.length-1; i++){
            sum += array[i];
            count++;
        }
        average = sum/count;
        System.out.println("Average :"+average); 
    }    
}
