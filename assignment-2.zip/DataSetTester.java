//*********************************
// Christine Chong
// cc4190
// 06/06/2017
//
// DataSetTester Class
//
// This class contains the main method.
//*********************************

import java.util.Scanner;

public class DataSetTester{
    
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter a list of numerical values seperated by ,");
        String list = input.next();
        DataSet n = new DataSet(list);
        n.add(list);
    }
}