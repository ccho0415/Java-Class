//*********************************
// Christine Chong
// cc4190
// 06/06/2017
//
// FactorGenerator Class
//
// This class contains the methods to
// check for and prints all the factors
// of a number.
//*********************************
public class FactorGenerator{
    
    private int number;
    private boolean isFactor;
    private int count = 2;
    
    public FactorGenerator(int num){
        number = num;
    }
    public boolean hasMoreFactors(){
        while(count < number){
            if(number%count == 0){
                count++;
                return true;   
            }else{
                count++;
            }            
        }
        return false;
        


    }
    public int nextFactor(){   
        return count-1;
    }
}