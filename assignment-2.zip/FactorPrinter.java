//*********************************
// Christine Chong
// 06/04/2017
//
// FactorPrinter Class
//
// This class tests your FactorGenerator Class.
// This class contains the main method.
//*********************************

import java.util.Scanner;

public class FactorPrinter{
    
    public static void main(String[] args){
        
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a number to be factored");
        int n = input.nextInt();

        FactorGenerator factor = new FactorGenerator(n);

        System.out.println("The factors are: ");
        while (factor.hasMoreFactors()){
            System.out.println(factor.nextFactor());
        }

    }

}    

