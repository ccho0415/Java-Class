//*********************************
// Christine Chong
// cc4190
// 06/06/2017
//
// Primary Factor Generator Class
//
// This class contains the methods to
// check for and prints all the prime factors
// of a number.
//*********************************
public class PrimaryFactorGenerator{
    
    private int number;
    private boolean isFactor;
    private int count = 2;
    private boolean prime = true;
    
    public PrimaryFactorGenerator(int num){
        number = num;
    }
    
    public boolean hasMoreFactors(){
        while(count < number){
            if(number%count == 0){
                if (count == 2){
                    prime = true;      
                }else{
                double countroot = Math.sqrt(count);
                double max = Math.ceil(countroot);                      
                    for(int i=2; i<=max; i++){
                        if(count % i == 0){
                            prime = false;
                        }
                    }
                }
                count++;
                return true;   
            }else{
                count++;
            }            
        }
        return false;
    }
    
    public int nextFactor(){  
        if(prime == true){
            prime = true;    
            return count-1;            
        }else{
            prime = true;            
            return 0;
        }
    }
    
}