//*********************************
// Christine Chong
// cc4190
// 06/06/2017
//
// PrimaryFactorPrinter Class
//
// This class contains the main method.
//*********************************

import java.util.Scanner;

public class PrimaryFactorPrinter{  
    
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a number to be factored");
        int n = input.nextInt();

        PrimaryFactorGenerator factor = new PrimaryFactorGenerator(n);

        System.out.println("The factors are: ");
        while (factor.hasMoreFactors()){
            if(factor.nextFactor()!=0){
                System.out.println(factor.nextFactor());
            }
        }
    }
    
} 
    
   

