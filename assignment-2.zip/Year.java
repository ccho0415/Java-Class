//*********************************
//
// Christine Chong
// cc4190
// 06/06/2017
//
// Year Class
//
// This class represents a calendar year.
//
// It contains a method that determines if
// the year is a leap year.
//*********************************


public class Year{
    
    private int year;
    
    public Year(int y){
        year = y;
    }
    
    public boolean isLeapYear(){
        if(year <= 1582){
            return false;
        }else if(year%4 == 0 && year%100 == 0){
            if(year%100 == 0 && year%400 == 0){
                return true;
            }else{
                return false;
            }
        }else if(year%4 == 0 && year%100 != 0){
            return true;
        }else{
            return false;
        }
    }
}    


