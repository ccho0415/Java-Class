**Note
For one of these assignments I redid the spacing using sublime text 
so there might be a giant copy paste over the original code.
I forgot which file this was for but I did add a comment in the bottom.
**
Circuit Class & Circuit Tester Class

    How to Use the Program:
    
        There is no need for any User Input.
 
    First let's write out a Truth Table to find all the possible combinations
    of switches and lamp.
    
    Assume 0 is Down / Off and 1 is Up / On.
    
    Let's start out with all 0s.
    
    F S L
    0 0 0
    1 0 1
    1 1 0
    0 1 1
    
    Now we have this Truth Table. We can start pseudo coding in the switches
    and lamps.
    
    Global Variables
    
        Int SwitchState1 = 0 (Down)
        Int SwitchState2 = 0 (Down)
        Int LampState = 0 (Off)
        
    Methods
    
        Get First Switch State
            Return the value for Switch State 1
        Get Second Switch State
            Return the value for Switch State 2
        Get Lamp State
            Return the value for the Lamp State
        Toggle First Switch
            if the First Switch State is Down
                Assign it a new value of Up
            else 
                Assign it a new value of Down
            if the Lamp State is Down
                Assign it a new value of Up
            else 
                Assign it a new value of Down                
        Toggle Second Switch
            if the Second Switch State is Down
                Assign it a new value of Up
            else 
                Assign it a new value of Down                
            if the Lamp State is Down
                Assign it a new value of Up
            else 
                Assign it a new value of Down 
                
    All of the methods and variables above can go in the Circuit Class
    Second let's try to replicate the Truth Table using the methods in 
    the Circuit Tester Class.
    
        F S L
        0 0 0 
        Get First Switch State -> 0
        Get Second Switch State -> 0
        Get Lamp State -> 0
        
        F S L
        1 0 1
        Toggle First Switch
        Get First Switch State -> 1
        Get Second Switch State -> 0
        Get Lamp State -> 1 
        
        F S L
        1 1 0
        Toggle Second Switch
        Get First Switch State -> 1
        Get Second Switch State -> 1
        Get Lamp State -> 0
        
        F S L
        0 1 1
        Toggle First Switch
        Get First Switch State -> 0
        Get Second Switch State -> 1
        Get Lamp State -> 1  

    I chose to design the code this way because I wanted the output to be as simple as a truth table.

Bug Class & Bug Test Class

    How to Use the Program:
    
        There is no need for any User Input.
 

    First we would want variables and methods to manipulate
    the position and direction.
    
    The Pseudo Code:
        
        Global Variables
            
            Int Position
            Int Direction = 0
        
        Constructor
        
            Set the position as the inputted position
        
        Methods
            
            Turn
                Change the direction. (Switch the value from 0 to 1 or 1 to 0)
            Move
                If the direction is positive move the position by 1.
                Print the Position.
                
                If the direction is negative move the position by 1.
                Print the Position.
            Get the Position
                Return the value of the Position
                
    All of the methods and variables above can go in the Bug Class
    Second let's write in some methods in the Bug Tester Class.
    
        Ask for the position of the Bug Object
        Create a new Bug Object
        Make Bug Object Move 
        Make Bug Object Turn
        and etc.
        
    I chose to design the code this way because I wanted to keep the output to be simple.

Data Set & Data Set Tester Class
    
    How to Use the Program:
    
        Please write a list of inputs like the list below when prompted.
            Ex: 
                1,2,3,4
        (No spaces and each numeric value seperated by a comma).
        

    First let's write down the input and how it should be processed.
    
        Input:
            Number 1, Number 2, Number 3, Number 4
        
        If the expected input is a string of numbers seperated by a comma,
        we can use the native Java Method of split using "," as the argument.
        After using split, the list should be sorted into a string array:
            String Array = [Number 1, Number 2, Number 3, Number4]
            
        Next we should write in a check to make sure that we are getting in an string of Floating
        Point Numbers. We can do this by using the Character.isLetter() method to look for letters.
        There are limits to this method of checking as this method cannot check for symbols that are
        not alphanumeric and it does not check for extra spaces.
        
        Using this verified string array, we can iterate through it with a for loop and convert
        the indexes into double indexes. The double indexes will allow us to do the math
        comparisons and calculations needed later.
            Double Array = [Number 1, Number 2, Number 3, Number4]
        
        Next we should sort the array using Insertion sort. (Similar code to the one used in class).
            Compare first index and second index
                if the second index is less than the first index replace the second index with the first
                index, and replace the first index with the second index.
            Continue until the sorting is finished.
        
        After the array is sorted we should figure out the smallest, largest and range in one method.
            Assign the smallest number as the first index of the array.
            Assign the largest number as the last index of the array
            Take the largest number and subtract it from the first to get the range.
       
       Next we should find the average of all the numbers.
            Add all the numbers together and divide that sum by the length of the array.
   
    All of the methods and variables above can go in the Data Set Class
    Second let's write in some methods in the Data Set Tester Class.
        
        Ask the User for a list of numbers seperated by a comma.
        Use the Scanner to take in user input.
        Create a new Data Set Object with this input.
        Print out the Output.
    
    Limitations:
        The Program will not work as intended if there are spaces in between each item of the list because Scanner seperates
        inputs if there is whitespace.
            If you add a System.out.println to see what the list looks like if there are spaces inserted it will cut off any values 
            after the first whitespace. 
        The Program does not check for non alphanumeric values. So values like $ will still go through and cause errors
        when it comes to the number processing part.
  
    I chose to design the code this way because I only know how to work with arrays. (Professor Cannon explained the other method of
    solving this problem).
    
Leap Year Class
 
    How to Use the Program:
        Please put a numerical value as the input when prompted:
            Ex: 
                2017
  
    First let's write down the conditions for a Leap Year.
        1. Year must after 1582.
        2. Year must be divisible by 4 years.
        3. If the year is divisible by 100 it is not a leap year except if it is divisible by 400 years.
    
    This means that we should write in 3 Checks (3 If Else Statements) to check and see if the inputted year is a Leap Year
    
    Global Variable
        Int Year
        
    Constructor
        Set the year as the inputted year
    
    Method
        IsLeapYear
            Check If The Year is Less Than or Equal to 1582
                Yes -> Not a Leap Year
                No -> Check if the Year is Divisible by 4 and 100
                      Yes -> Check if the Year is Divisible by 400
                             Yes -> A Leap Year
                             No -> Not a Leap Year
                      No -> Check if the Year is Divisible by 4 and not 100
                             Yes -> A Leap Year
                             No -> Not a Leap Year                      

    Now with the user input from the Leap Year Tester program, we can check if the year is a Leap Year.
    Limitations:
        The program will not be able to take inputs that are non numeric.
        If the Year is Negative, the program will say that it is not a Leap Year. (Even though it is not a proper year).
        It only takes into accounts the 3 conditions stated earlier. If there are other conditions, they will not be checked for.
   
   I chose to design the code this way because I was limited to the template. I originally had a file with the code structured in a way 
   that broke down these checks, but then realized I was not allowed to do that so I just copied over most of the code and rewrote it so that
   there is only 1 function that has these checks. (This is the reason why there might've been a giant copy paste) 
        
Factor Generator Class

    How to Use the Program:
        Please put a numerical value as the input when prompted:
            Ex: 
                56
      
    First let's write down the condition for a number to be a factor
        1. It must divide into another number with no remainder
    
    This means that we should use the modulo operator to check to see if the numbers are divided with no remainder
        Check if the number % second number is == 0
            Yes -> Return this Value
            No -> Do not Return this Value
    We should check if this condition is true for all numbers (besides 1 and 0) under the inputted number
        While the check count is less than the inputted number
            Check if it is a factor
    Limitations:
        The program will not be able to take inputs that are non numeric
        The program will not work if there is a negative number as the input.
        The program will not output as intended if the input value is 1 or 0.
        The program will not output as intended if the input value is prime.
        
    I chose this design because I was limited by template.

Primary Factor Generator & Primary Factor Printer Class

    How to Use the Program:
        Please put a numerical value as the input when prompted:
            Ex: 
                56
      
    First let's write down the condition for a number to be an output
        1. It must divide into another number with no remainder
        2. This number must be prime
    
    This means that we should use the modulo operator to check to see if the numbers are divided with no remainder
        Check if the number % second number is == 0
            Yes -> Check if this Number is Prime
                   Yes -> Return this Value
                   No -> Do not Return this Value
            No -> Do not Return this Value
            
    We should check if this condition is true for all numbers (besides 2, 1, and 0) under the inputted number
        While the check count is less than the inputted number
            Check if it is a factor that is prime
   
   Second let's write some methods for the Primary Factor Printer Class
        Ask User for Numeric Input
        While There are More Factors and If the Factor is not 0
            Print the Prime Factor
        
    Limitations:
        The program will not be able to take inputs that are non numeric
        The program will not work if there is a negative number as the input.
        The program will not output as intended if the input value is 1 or 0.
        The program will not output as intended if the input value is prime.    
        
     I chose this design because I was limited by template.
