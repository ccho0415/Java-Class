
//***************************************
// This is the test class for the 
// Bulls and Cows assignment
//
// Your application must use this main method
//****************************************

public class BullsAndCows {

    public static void main(String[] args){
        Game g = new Game();
        g.playGame();
    }   
}
