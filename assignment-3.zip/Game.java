import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
//**********************************************
// This is the Game class for the Bull and Cows
// program. You will need to modify this template
//
//**********************************************

public class Game{

// Here we are establishing global variables
    private int turns;
    public Oracle computer;
    private Scanner input;
    private String pattern;
    public String guessString = "";
    public String patternTrunc = "";
    public String guessTrunc = "";
    public String guessed = "";
    public int bulls;
    public int cows;    

    public Game(){
    computer = new Oracle();

    }

    public void playGame(){
        computer.generatePattern();
        pattern = computer.getPattern();
        playOneTurn();  
    }
    
    public void playOneTurn(){
// Ask for user input here
        System.out.println("Please enter a 4 digit number ");
        Scanner input = new Scanner(System.in);
        while (!input.hasNextInt()){
            System.out.println("That is not a number");
            input.next();
        }    
        guessString = input.nextLine();
// Validate the User Input
        ValidateString userguess = new ValidateString(guessString);  
        userguess.checkLength(guessString);
        turns++;
        System.out.println("Playing");
// Check for 4 bulls        
        if (guessString.equals(pattern)){
            bulls = 4;
            System.out.println("4 Bulls. Hooray You Win!");
            System.out.println(" Turns : "+ turns);
        }else{
// Set a List Array to be filled           
            List<String> values = Arrays.asList(null, null, null, null);
            for(int i=0; i<guessString.length(); i++){
                if(guessString.charAt(i)==pattern.charAt(i)){
                    values.set(i, "bull");
                }else{
// Set a Second Pair for Strings to Compare for Cows                    
                    patternTrunc = patternTrunc + pattern.charAt(i);
                    guessTrunc = guessTrunc + guessString.charAt(i);
                 }
             }
// Compare the Second Pair of Strings for Cows            
             for(int j=0; j<patternTrunc.length(); j++){
                String current = guessTrunc.substring(j, j+1);
                if(patternTrunc.contains(current) && !guessed.contains(current)){
                    guessed = guessed + guessTrunc.charAt(j);
                     for(int k=0; k<values.size(); k++){
                         if(values.get(k) == null){
                             values.set(k, "cow");
                             break;
                         }
                     }                             
                }else{
                    for(int k=0; k<values.size(); k++){
                        if(values.get(k) == null){
                            values.set(k, "false");
                            break;
                        }
                    }               
                }   
             } 
// Have the system Print out Turns, Find Bulls and Cows and Find Them        
             System.out.println("Turns: "+ turns);
             reset();
             bulls = computer.howManyBulls(values);
             cows = computer.howManyCows(values);
             System.out.println(" Bulls: "+ bulls);
             System.out.println(" Cows : "+ cows);
             playOneTurn();   
         }    
    }

    public void setPattern(String solution){
    // This method is complete. Don't touch it.
    // it is here to allow us and you to test your code. 
    // You should only use this method to help you test
    // your code while developing.

        computer.setPattern(solution);
    }

    public String getPattern(){
    // This method is complete. Don't touch it.
    // This method is here to allow us and you
    // to test your code. You should only use 
    // this method to help you test your code
    // while you are developing your program.

        return computer.getPattern();
    }
//  Reset these values because they are being concatenated   
    public void reset(){
        guessString = "";
        patternTrunc = "";
        guessTrunc = "";
        guessed = "";        
    }

}
