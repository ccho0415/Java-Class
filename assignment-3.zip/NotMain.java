import java.util.Scanner;
// ------------------------Guess Validation System-----------------
// public class NotMain{
//     public String guess;
//     public NotMain(String guessin){
//         guess = guessin;
//     }
//     public void ask(){
//         System.out.println("Please enter a 4 digit number ");
//         Scanner in = new Scanner(System.in);
//         while (!in.hasNextInt()){
//             System.out.println("That is not a number");
//             in.next();
//         }            
//         int guessnum = in.nextInt();
//         guess = Integer.toString(guessnum);
//         checkLength(guess);
//     }
//     public void checkLength(String guessin){
//         if (guessin.length() != 4){
//             System.out.println("Not a Length of 4");
//             ask();
//         }else{
//             System.out.println("You guessed : "+ guess);
//         }       
//     }
// ------------------------------------------------------------------      

}