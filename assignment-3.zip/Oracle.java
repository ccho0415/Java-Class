import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
//***********************************
// This is a template for your Oracle
// class
//
//***********************************


public class Oracle{
    
    private String pattern = "";
    public int bulls = 0;
    public int cows = 0;
    public Oracle(){
    // your code here for setting up
    // an Oracle object
    }

    public void setPattern(String solution){
    // This method is complete. Don't touch it.
    // This method is here to allow us and you
    // to test your code. You should only use 
    // this method to help you test your code
    // while you are developing your program.

        pattern = solution;
    }

    public String getPattern(){
    // This method is complete. Don't touch it.
    // This method is here to allow us and you
    // to test your code. You should only use 
    // this method to help you test your code
    // while you are developing your program.

        return pattern;
    }
// Look for the bulls in the List Array and increment by 1 if there is a bull
    public int howManyBulls(List<String> guess){
        bulls = 0;
        for(int k=0; k<guess.size(); k++){
            if(guess.get(k) == "bull"){
                bulls++;
            }
        }
    return bulls;
    }
// Look for the cows in the List Array and increment by 1 if there is a cow
    public int howManyCows(List<String> guess){
        cows =0;
        for(int k=0; k<guess.size(); k++){
            if(guess.get(k) == "cow"){
                cows ++;
            }
        }
        return cows;
    }

    // any other methods you might want
    // in this class can go here
    // Creating a random 4 digit pattern with unique numbers at each digit
    public void generatePattern(){
        while(pattern.length()<4){
            int number = (int) (Math.floor(Math.random()*9+0));
            String numberString = Integer.toString(number);
            if(!pattern.contains(numberString)){
                pattern = number + pattern;   
            }
         }
         System.out.println("The numbers are : " + pattern);        
    }
}
