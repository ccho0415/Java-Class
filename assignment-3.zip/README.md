## COMS S1004
## Assignment 3 
## Due June 13 at 11:59PM 
_________________________________________

 

### PROBLEM SET  

Do the following problems in Schneider and Gersting (7th edition):

Be sure to show your work for all problems!

Chapter 4: (15 points) 19, 25, 26

Chapter 5: (15 points) 18, 20, 21

Recommended: (not for credit):

Chapter 4: 1, 4, 8, 9, 13, 15, 24

Chapter 5: 2, 3, 9, 12, 19, 22

 **What to hand in:**   

Submit a single pdf file for these problems. Name the file ProblemSet3.pdf


### PROGRAMMING (70 points)

#### Bulls and Cows

Write an application in Java that allows a user to play the game Bulls and Cows against a computer. The game works as follows: The computer chooses a 4-digit number in secret. The digits must all be different.  The user then guesses the number and the computer provides the number of matching digits. If the matching digit is in the right position it is a "bull", if it is on a different position it is a "cow". For example:

Computer chooses:  3691

User guesses:  1649

Computer answers: 1 bull and 2 cows

If the user guesses a number with repeat digits that is partially correct the rule is that a correct digit can only count once and bulls count before cows. So for example

Computer chooses:  3691

User guesses:   4211

Computer answers: 1 bull and 0 cows

Your program should report the number of attempts the user needed to guess the number at the end of the game.

**Design:**  Your program must use the attached BullsandCows.java test class. This means that you must NOT write your own main method. Your code must work with the main method contained in BullsandCows.java

Your program should consist of two additional classes: Game and Oracle. All input and output should happen in the Game class. This is where you will ask the player for their guess and this is where you will tell the player how many bulls and cows they got. The Oracle class should store the actual computer choice as a String and have methods to determine how many bulls and cows any given guess would generate. I have provided templates for both of these classes. Notice that they each contain a set method and a get method for the solution pattern. This is for grading purposes only. Do not edit the setPattern or getPattern methods. Leave them alone. Edit these templates by adding code to the other existing methods, creating new methods, and/or adding more instance variables. To earn full credit you are required to use these files and the test  class file BullsandCows.java must remain unchanged. 

For aspiring hackers:  (not for credit): Write a class that computerizes the human user and requires on average less than 8 turns to guess the pattern. Write a new test class and a Simulator class (the Simulator class will sub for the Game class) to demonstrate this ability by playing 1000 games of computer versus computerized user and reporting the average number of guesses. This should be done in addition to the regular assignment for full + extra credit.


**What to hand in**:

Templates for the three source files are located in the Assignment 3 workspace on Codio. In addition to the source files  include a text file named readMe.txt with an explanation of how your program works. That is, write in plain English, instructions for using your software, explanations for how and why you chose to design your code the way you did. The readMe.txt file is also an opportunity for you to get partial credit when certain requirements of the assignment are not met.  Put the readMe.txt file in the same directory as your source and use the usual submission instructions for submitting the assignment.
 
 

### Submitting your work:

For this assignment you should have three types of files: A single PDF file for the problem set, three .java files that are the source code for your program, and a single text file named readMe.txt . The templates for everything but the pdf file are already loaded into your Asignment 3 workspace. You must upload the ProblemSet3.pdf file onto your Assignment 3 workspace. Once you have completed your assignment and uploaded the ProblemSet3.pdf file you just need to switch the completed switch on Codio.

### A word about Grading: 
The question on the prblem set is worth 5 ponts. The programming portion of the assignment is worth 70 points and we will use the following guideline for awarding points:

* 30% if it compiles  
* 30% if it runs properly (expected output for given input, etc.)  
* 20% for style (formatting of code, variable names, comments, etc. Use the style guide posted on Coursworks!)  
* 20% for design (efficiency, short methods, etc.)  

Please make sure your program at least compiles before you submit it! There will be no partial credit for a program that "almost" compiles.

