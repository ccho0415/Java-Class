import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class Test{
    public static void main(String[] args){
     
// -------------------------RNG-----------------------------------        
//         String numbers = "";
//         while(numbers.length()<4){
//             int number = (int) (Math.floor(Math.random()*9+0));
//             String numberString = Integer.toString(number);
//             if(!numbers.contains(numberString)){
//                 numbers = number + numbers;   
//             }
//          }
//         System.out.println("The numbers are : " + numbers);
//-----------------------------------------------------------------
// ------------------------Guess Validation System-----------------
//         System.out.println("Please enter a 4 digit number ");
//         Scanner input = new Scanner(System.in);
//         while (!input.hasNextInt()){
//             System.out.println("That is not a number");
//             input.next();
//         }    
//         int guess = input.nextInt();
//         String guessString = Integer.toString(guess);
//         NotMain userguess = new NotMain(guessString);  
//         userguess.checkLength(guessString);
// ------------------------------------------------------------------ 
// ---------------------------Bulls and Cows----------------------------------
//     String test = "1234";
//     String guess = "5555";
//     String test2 = "";
//     String guess2 = "";
//     String guessed = "";
//     int bulls = 0;
//     int cows = 0;
//     int turns = 0;
        
//     if (guess.equals(test)){
//         bulls = 4;
//         System.out.println("4 Bulls. Hooray You Win!");
//     }else{
//         turns ++;
//         List<String> values = Arrays.asList(null, null, null, null);
//         for(int i=0; i<4; i++){
//             if(guess.charAt(i)==test.charAt(i)){
//                 System.out.println(" Bull! ");
//                 values.set(i, "bull");
//             }else{
//                 test2 = test2 + test.charAt(i);
//                 guess2 = guess2 + guess.charAt(i);

//             }
//         }
//         System.out.println(""+ test2);
//         System.out.println(""+ guess2);
//         for(int j=0; j<test2.length(); j++){
//            String current = guess2.substring(j, j+1);
//            if(test2.contains(current) && !guessed.contains(current)){
//                guessed = guessed + guess2.charAt(j);
//                 for(int k=0; k<values.size(); k++){
//                     if(values.get(k) == null){
//                         values.set(k, "cow");
//                         break;
//                     }
//                 }                             
//            }else{
//             for(int k=0; k<values.size(); k++){
//                if(values.get(k) == null){
//                    values.set(k, "false");
//                    break;
//                }
//             }               
//            }   
//         }
//         System.out.println(""+ guessed);
//         System.out.println(""+ values); 
        
//     }
// ------------------------------------------------------------------------        
     }
    }