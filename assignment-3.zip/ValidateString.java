import java.util.Scanner;

public class ValidateString{
    public String guess;
    public ValidateString(String guessin){
        guess = guessin;
    }
// Looking for a Numerical Input
    public void ask(){
        System.out.println("Please enter a 4 digit number ");
        Scanner in = new Scanner(System.in);
        while (!in.hasNextInt()){
            System.out.println("That is not a number. Please enter a number.");
            in.next();
        }            
        String guessnum = in.nextLine();
        checkLength(guessnum);
    }
// Looking for 4 Digits
    public void checkLength(String guessin){
        if (guessin.length() != 4){
            System.out.println("Not a Length of 4");
            ask();
        }else{
            System.out.println("You guessed : "+ guess);           
        }       
    }
     

}