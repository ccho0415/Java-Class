**Added a Validate String Class to Work Around Possible User Input Errors**
**Kept the Test Classes (Test and Not Main)**
PseudoCode
    Pick a random 4 digit number
        Pick a random number from 0-9
        Check if it has already been picked
        No ->
        Concatenate onto a String
        Yes ->
        Roll Again        
    Ask a User for A Guess
        Ask for 4 Digit Number
        Scanner for String
        If the length is not 4
            Error -> Ask Again
        Else
            Print Guess
    Calculate Bulls and Cows
        1234
        1141
        Check if everything matches first
        if yes
            bulls -> 4
            End game
        if not
            turns ++
            Set a List of nulls
                [null null null null]
            Go through the guess and find all bulls
                if it is a bull change it to true
                if it is not push to original to string 2
                and push guess to string 3
                    [bull, null, null , null] 
                    String 2 : 234
                    String 3 : 441
                compare string 2 and 3
                    if it is a cow then push it to a string 4 and change the first avaliable null to to cows
                    else if it is a "cow" but it is part of string 4 change the first avaliable null to false
                    else change the first avaliable null to it is false
                    [bull, cow, false false]
                    String 4: 4
            
    Print out Bulls and Cows Guess ++
        Check through list and check value
            if bulls -> bulls ++
            if cows -> cows ++
Design Philsophy
    The design was centered around the idea that I should suggest a problem first and try to find a solution. If the solution has it's own problem, try
    to modify the solution to work around the problem.
        If there was a string 1234 and if there was a string 1141, how would I get the correct output?
           Originally I thought of iterating through it and if there was a bull or a cow, to trim the strings of the bull and cow values.
            The issue with this method is that it could mess itself up very quickly and does not work if the user guesses 1144.
           So I decided to create a seperate string that keeps track of what values were already checked (because the values can only occur once)
            The issue now is finding a systematic way of keeping all the outputs in an organized fashion
           After that I decided to keep a list system.
            This way I can keep all the values in an organized fashion and I could do multiple checks, so that I do not have to check
            all the cows and bulls within one loop.(Trying to check within one loop got really messy)
     Also parts of the design are there because of the restrictions caused by the templates.
            
    
    